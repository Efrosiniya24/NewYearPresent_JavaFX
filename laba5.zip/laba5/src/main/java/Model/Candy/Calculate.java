package Model.Candy;

import Model.User.User;

public interface Calculate {
    double func(User user);
}
